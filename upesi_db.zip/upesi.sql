-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2019 at 10:59 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upesi`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `valname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `type`, `title`, `description`, `valname`, `created_at`, `updated_at`) VALUES
(1, 'value', 'Customer Obsession', 'Start with the customer and work backwards. Work vigorously to earn and keep customer trust. Pay attention to competitors, but keep obsessing over customers.', 'co', NULL, '2018-12-04 13:53:58'),
(4, 'value', 'Ownership', 'hink like an owner, Think long term and don’t sacrifice long-term value for short-term results. Act on behalf of the entire company, not just for own team. Never say “that’s not my job\".', 'o', '2018-12-04 13:54:25', '2018-12-08 13:31:43'),
(5, 'value', 'Invent and Simplify', 'Expect and require innovation and invention from everyone in the team and always find ways to simplify. Be externally aware, always look for new ideas from everywhere, and don’t be limited by “not invented here\".', 'ins', '2018-12-04 13:54:41', '2018-12-04 13:54:41'),
(6, 'value', 'Learn and be curious', 'You are never done learning and always seek to improve; you are curious about new possibilities and act to explore them.', 'lbc', '2018-12-04 13:54:59', '2018-12-04 13:54:59'),
(7, 'value', 'Insist on the Highest Standards', 'Have relentlessly high standards and continually raise the bar and drive each team member to deliver high quality products, services and processes.', 'inhs', '2018-12-04 13:55:16', '2018-12-04 13:55:16'),
(8, 'value', 'Collaboration Work', 'As a team, drive ownership and accountability, make decisions and get results. Foster trust, have integrity, champion each other and have each other’s’ backs. Eradicate silos and win as a team.', 'cw', '2018-12-04 13:55:37', '2018-12-04 13:55:37'),
(9, 'value', 'Wellness', 'Care and actively support each other’s well-being. Create a super energizing workplace that brings out the best in our employees by nourishing our mental, physical and emotional balance.', 'wel', '2018-12-04 13:55:55', '2018-12-04 13:55:55'),
(10, 'about', 'About us', 'Upesi is a homegrown African solution that enables efficient, reliable and affordable global money transfer. The Company is currently licensed in Kenya by the Central Bank of Kenya (CBK), and in the UK by the Financial Conduct Authority (FCA).\n\nHaving been incorporated in 2015 in Kenya, Upesi Money Transfer Limited started operations in Kenya in January 2016 upon issuance of the license by the Central Bank of Kenya. Upesi Money Transfer has also started the process of registering as money Transfer Company in other countries in the East African region.\n\nSince its inception Upesi Money Transfer Limited has experienced remarkable growth and is strategically placed for growth in the remittance space. The strength of our partnerships has contributed to the speedy growth of Upesi Money Transfer Limited.', 'au', NULL, '2018-12-08 13:37:25'),
(11, 'about', 'MISSION', 'To become Africa’s most innovative, customer centric, remittance solution, with the aim of achieving financial inclusion.', 'm', NULL, '2018-12-08 13:43:10'),
(12, 'about', 'VISION', 'To become Africa’s No. 1 remittance Solution', 'v', NULL, '2018-12-08 13:43:58');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orgnmessage` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `type`, `name`, `email`, `phonenumber`, `orgnmessage`, `created_at`, `updated_at`) VALUES
(1, 'assistance', 'eric', 'eric@gmail.com', '0728519621', 'orga', '2018-12-12 05:57:59', '2018-12-12 05:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(6, '2016_06_01_000004_create_oauth_clients_table', 2),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2),
(8, '2018_12_04_115027_create_about_table', 3),
(9, '2018_12_08_165327_create_services_table', 4),
(10, '2018_12_09_151528_create_policies_table', 5),
(11, '2018_12_09_175257_create_contacts_table', 6),
(12, '2018_12_17_212008_create_teams_table', 7),
(14, '2018_12_18_052851_add_info_field', 8);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', '0Qc2Nybn30fUlTze3mxAmnoIJYJk3Fnz1EZ60Dr3', 'http://localhost', 1, 0, 0, '2018-11-30 07:05:40', '2018-11-30 07:05:40'),
(2, NULL, 'Laravel Password Grant Client', 'wmytoa4VTzksbszoy7sEROWKYSkIuevhx99dBXMk', 'http://localhost', 0, 1, 0, '2018-11-30 07:05:40', '2018-11-30 07:05:40');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2018-11-30 07:05:40', '2018-11-30 07:05:40');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `policies`
--

CREATE TABLE `policies` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `looppicker` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `policies`
--

INSERT INTO `policies` (`id`, `type`, `title`, `description`, `looppicker`, `created_at`, `updated_at`) VALUES
(1, 'faqs', 'How do I register an account?', 'We are required by the regulator to take some basic information from you. The registration process is short and simple. ‘Register here’ link.', 'register', '2018-12-09 13:42:19', '2018-12-09 13:42:19'),
(2, 'faqs', 'How do I transfer money to Kenya?', 'You can transfer money to mobile wallets, bank accounts or cash pick-ups. ‘Send Money’ link.', 'transfer', '2018-12-09 14:00:58', '2018-12-09 14:00:58'),
(3, 'faqs', 'How much do you charge?', 'we charge 0 amount to send money', 'charge', '2018-12-09 14:01:32', '2018-12-09 14:01:32'),
(4, 'faqs', 'How much can I send?', 'You can send up to a maximum of £9000 per day per month', 'send', '2018-12-09 14:02:01', '2018-12-09 14:02:01'),
(5, 'faqs', 'Does the recipient pay any charges to get money?', 'The recipient does not pay any amount to receive money', 'recipient', '2018-12-09 14:02:30', '2018-12-09 14:02:30'),
(6, 'faqs', 'Can I send money on weekends or public holidays?', 'Yes. Our services are 24/7', 'weekends', '2018-12-09 14:02:55', '2018-12-09 14:02:55'),
(7, 'faqs', 'I am not able to register online, what should I do?', 'Send us an email at info@upesi.co.ke, and we shall call you back to assist', 'online', '2018-12-09 14:03:16', '2018-12-09 14:03:16'),
(8, 'faqs', 'Can I modify my account details?', 'Yes. You can edit your account details such as address, phone number, and location. You may not modify other details such as ID/passport number, and Name', 'modify', '2018-12-09 14:03:53', '2018-12-09 14:03:53'),
(9, 'faqs', 'Can I cancel a transaction?', 'Yes. You can cancel a cash pick-up transaction, if the recipient has not received it yet. Bank transactions and mobile wallet transactions that are instant, cannot be cancelled', 'cancel', '2018-12-09 14:04:13', '2018-12-09 14:04:13'),
(10, 'faqs', 'How long does a money transfer take?', 'Mobile wallet transactions and bank transactions are instant. Cash pick-up transactions are ready for collection after 10 minutes', 'mt', '2018-12-09 14:04:33', '2018-12-09 14:04:33'),
(11, 'faqs', 'Is my data secure on your platform?', 'Yes. We secure all customer data using a multilayer security system. The data is encrypted and hosted on a secure server.', 'secure', '2018-12-09 14:04:53', '2018-12-09 14:04:53'),
(12, 'faqs', 'Is there any limit for sending money?', 'No. There’s no limit in sending money. However, above USD 5000, the customer may be requested to provide proof of source and purpose of funds', 'limit', '2018-12-09 14:05:12', '2018-12-09 14:05:12'),
(13, 'termsnprivacy', 'Privacy Policy', 'Our privacy policy explains how we treat your personal data and protect your privacy when you use our Services. By using our Services, you agree that Upesi can use such data in accordance with our privacy policies.\n\nWe respond to notices of alleged copyright infringement and terminate accounts of repeat violators of copyright infringement according to the process defined in the Kenya Data Protection Bill 2013\n\nWe collect information in two ways:\nInformation you give us.\nIf our Services require you to sign up for a Upesi account, and or if, you do, you may have to provide personal information. We will not in any way use any financial information you submit in conjunction of creating an account, unless allowed by law. We do often encourage ways to take full advantage of the sharing features we offer. This may include using personal information to create publically visible profiles that may or may not include names, photos and other personal information. You can request in writing to not have your information displayed publically in any manner, in conjunction with signing up for a Upesi account as part of a Service requirement.\n\nInformation we get from your use of our Services.\nWe may collect information about the additional services that you use and how you use them, as it applies to advertising and content specific promotions.\n\nWarranties and Disclaimers\nWe provide our Services using a commercially reasonable level of skill and care and operate within all national laws. However, Upesi does not make specific promises about the use of our Services or the success of using our Services. The following statements apply:\n\nOTHER THAN AS EXPRESSLY SET OUT IN THESE TERMS OR ADDITIONAL TERMS, NEITHER UPESI NOR ITS SUPPLIERS OR DISTRIBUTORS MAKE ANY SPECIFIC PROMISES ABOUT THE SERVICES. WE DO NOT MAKE ANY COMMITMENTS ABOUT THE CONTENT WITHIN THE SERVICES, THE SPECIFIC FUNCTIONS OF THE SERVICES, OR THEIR RELIABILITY, AVAILABILITY, OR ABILITY TO MEET YOUR NEEDS. WE PROVIDE OUR SERVICES “AS IS”.\n\nSOME JURISDICTIONS PROVIDE FOR CERTAIN WARRANTIES, LIKE THE IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. TO THE EXTENT PERMITTED BY LAW, WE EXCLUDE ALL WARRANTIES.\n\nAbout these Terms\nWe may modify these terms or any additional terms that apply to a Service to reflect changes to the law or changes to our Services. Upesi will post notice of modifications to these terms on this page. We will post notice of modified additional terms in the applicable Service. Changes will not apply retroactively and will become effective no sooner than fourteen days after they are posted. However, changes addressing new functions for a Service or changes made for legal reasons will be effective immediately. If you do not agree to the modified terms for a Service, you should discontinue your use of that Service.\n\nIf there is a conflict between these terms and the additional terms, the additional terms will control for that conflict.\n\nThese terms control the relationship between Upesi and you. They do not create any third party beneficiary rights.\n\nIf you do not comply with these terms, and we do not take action right away, this does not mean we are forfeiting any rights that we may have (such as taking action in the future).\n\nIf you have any questions or concerns about our Services or these Terms, you may contact us.', '', NULL, '2018-12-09 14:13:26'),
(14, 'termsnprivacy', 'Terms of Use', 'You must follow any policies made available to you with the use of our Services.\n\nWe do not allow misuse, unauthorized resell or abuse of our Services. By accepting use of our Services, you agree to not interfere with our Service stipulations, access our Service using a method other than what is included in your contract with us and outlined in the instructions agreed upon. You may use our Services only as permitted by law, including applicable export and re-export control laws and regulations. We may suspend, revoke or terminate our Services to you if you do not comply with our terms or policies or if we are investigating suspected misconduct or fraudulent activity.\n\nUsing our Service does not give ownership of intellectual property rights to any of our content that you have contracted with us to access. You may not use content from our Services unless written permissions are obtained from their rightful owners or are otherwise permitted by law. These terms do not grant the right to use any branding or logos associated with our Services without written expressed permission. You agree not to remove, obscure, or alter any legal notices displayed in or along with our Services, failure to comply will result in the revocation, suspension or termination of use of our Services and/or legal recourse.\n\nOur Services many times display proprietary content. In regards to this content: the content is the sole responsibility of the entity that makes it available, however, by using our Service, you agree to allow Upesi, if deemed necessary, the right to review this content to determine whether it is illegal or violates our policies, and that we may remove or refuse to display content that we reasonably believe violates our policies or the law.\n\nIn connection with your use of our Services, you agree that we may send you Service notifications, announcements, administrative messages, and other information pertaining to the use of our Services. After acceptance of these agreements, you may opt-out of some of these communications.\n\nBy using our Services on mobile devices, you agree to not use our Services that are in a manner to distract, detour or increase risk during operation of a moving vehicle or when obeying traffic and safety laws. By using our Services, you agree to hold Upesi harmless for any activity that causes injury, damages property or violates laws in accordance with these terms.', '', NULL, '2018-12-09 14:13:39');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `type`, `title`, `description`, `created_at`, `updated_at`) VALUES
(6, 'service', 'Bank Deposits', 'Receive instant bank transactions to banks in Kenya, Uganda and UK', '2018-12-08 15:54:04', '2018-12-08 15:54:04'),
(7, 'service', 'Cash Pick Ups', 'Pick cash from any of our branches or partners in Kenya, Uganda and UK', '2018-12-08 15:54:36', '2018-12-08 15:54:36'),
(8, 'service', 'Mobile Wallets', 'Receive money on your phone instantly through our mobile money..', '2018-12-08 15:54:53', '2018-12-08 15:54:53'),
(9, 'service', 'Direct bill payments', 'Pay your utility bills anytime, from anywhere in the world...', '2018-12-08 15:55:21', '2018-12-08 15:55:21');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'profile.png',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `info` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `looppicker` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `title`, `photo`, `remember_token`, `created_at`, `updated_at`, `info`, `looppicker`) VALUES
(3, 'John Mwenja Ngumba', 'CEO', '1545116159.jpeg', NULL, '2018-12-18 03:56:01', '2018-12-18 03:56:01', 'Mr. Ngumba, the CEO of Upesi Money Transfer Limited, has a wealth of experience in the financial sector and also having been a member of the diaspora. He is well versed with the challenges facing East and Central Africans community abroad especially when it comes to remitting money back home.\n\nHe recognizes that the global positioning of Africa is at its peak with the major powers competing to get a foothold into the continent and thus his aim is to make a positive impact in Africa by creating a revolution on the money transfer concept with the major aim of ensuring that every stakeholder in the value chain gets the best out of the service provision.', 'john'),
(4, 'Kenneth Kiura Njora', 'Deputy CEO', '1545117478.jpeg', NULL, '2018-12-18 04:17:59', '2018-12-18 04:17:59', 'He is a Certified Public Accountant of Kenya (CPA, K) and an Associate of the Association of the Chartered Certified Accountant (ACCA, UK). He is also an Associate of the Chartered Institute of Management Accountants (CIMA). He has worked as the Group Financial Controller for Pacific Group of Companies a leading insurance and reinsurance broker for a period of 8 years. He is a Consultant with vast experience in the fields of Audit and Accounting gained over a period of 16 years. He is a Director in Ngao Credit Limited and also holds Directorships in other well established companies.', 'ken'),
(5, 'Trevor Kimani', 'Chief Operations Officer', '1547026849.jpeg', NULL, '2018-12-18 04:18:54', '2019-01-09 06:50:25', 'He has experience in building financial businesses having spear headed the immense growth of other financial institutions implementing effective policies that allowed the organizations to grow seamlessly over the past 10 years. He has a bachelors degree in Business Administration from the university of Kent (England) and a Global Executive MBA from the United States International University Africa. He specializes in building start-ups primarily through business model generation and organizational development', 'trevor');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `bio` mediumtext COLLATE utf8mb4_unicode_ci,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'profile.png',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `type`, `bio`, `photo`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'eric', 'eric.ndungu16@gmail.com', '$2y$10$M76GLHs1P7FWGrO0HustG.kzwzVYBE66hNDO4QLMjM/Nr8AMglnLi', 'admin', NULL, 'profile.png', '92SSWt1vLbMHzT3s9apLnroQI28UO7DtA9NwX2Ah3sGj775SthWBQHJ0hvLn', '2018-11-30 04:58:17', '2018-12-18 09:52:37'),
(3, 'joseph ndegwa', 'joseph@belva.co.ke', '$2y$10$ep3ScZE0kuWQLfRcQi44Neqm5A9rRK0ECvgPxv.LnUrRviwBNgxIm', 'admin', NULL, 'profile.png', 'kaStGNbwHplDp2phviBWQVt8qrLgsFXJOwtCbO8mxSOusBX5RIJTCdBEbO7I', '2018-12-18 09:52:03', '2018-12-18 09:52:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `policies`
--
ALTER TABLE `policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `policies`
--
ALTER TABLE `policies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
